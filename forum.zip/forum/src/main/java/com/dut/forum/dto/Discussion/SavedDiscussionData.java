package com.dut.forum.dto.Discussion;

import lombok.Data;

@Data
public class SavedDiscussionData {
    private String userId;
    private long discussionId;
}
