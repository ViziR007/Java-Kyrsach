package com.dut.forum.services.services;

import com.dut.forum.services.interfaces.IRolesService;
import org.springframework.stereotype.Service;

@Service
public class RolesService implements IRolesService {
}
