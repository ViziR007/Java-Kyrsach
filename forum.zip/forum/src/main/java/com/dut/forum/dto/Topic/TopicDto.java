package com.dut.forum.dto.Topic;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TopicDto {
    private long id;
    private String name;
}
