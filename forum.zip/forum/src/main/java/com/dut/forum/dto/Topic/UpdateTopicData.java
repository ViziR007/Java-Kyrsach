package com.dut.forum.dto.Topic;

import lombok.Data;

@Data
public class UpdateTopicData {
    private long id;
    private String name;
}
