package com.dut.forum.dto.Comment;

import lombok.Data;

@Data
public class UpdateCommentData {
    private long id;
    private String text;
}
