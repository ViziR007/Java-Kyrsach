package com.dut.forum.services.interfaces;

public interface IRolesService {
}
